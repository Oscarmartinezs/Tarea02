class Ingresos:
    def __init__(self):
        self.ingresos = []

    def Ingreso(self):
        IngresoUsuario = int(input("Tu ingreso es de : $ "))
        self.ingresos.append(IngresoUsuario)

    def SumaIngresos(self):
        ingreso1 = sum(ingresos)
        return ingreso1

    def ReportarCantidadIngresos(self):
        for ingresoscontador in self.ingresos:
            print(ingresoscontador)

    def LosIngresosTotales(self):
        return self.ingresos
