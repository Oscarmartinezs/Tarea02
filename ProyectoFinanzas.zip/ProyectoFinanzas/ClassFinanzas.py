class FinanzasUsuario:
    def __init__(self):
        pass

    def Usuario(self):
        Nombre = input("Ingresa tu nombre por favor: ")
        print(f"Bienvenido {Nombre}")
