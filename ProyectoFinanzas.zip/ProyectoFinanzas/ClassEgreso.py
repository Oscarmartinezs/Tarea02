class Egresos:
    def __init__(self):
        self.egresos = []

    def Egreso(self):
        EgresoUsuario = int(input("Registra tus Egresos: $"))
        self.egresos.append(EgresoUsuario)

    def SumaEgresos(self):
        egreso1 = sum(egresos)
        return egreso1

    def ReportarCantidadEgresos(self):
        for egresocontador in self.egresos:
            print(egresocontador)

    def LosEgresosTotales(self):
        return self.egresos
