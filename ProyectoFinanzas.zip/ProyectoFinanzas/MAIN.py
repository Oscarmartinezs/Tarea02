from ClassFinanzas import FinanzasUsuario
from ClassIngreso import Ingresos
from ClassEgreso import Egresos

InstanciaFinanzas = FinanzasUsuario()
InstanciaIngresos = Ingresos()
InstanciaEgresos = Egresos()


def Usuario():
    InstanciaFinanzas.Usuario()


def Ingreso():
    InstanciaIngresos.Ingreso()


def Egreso():
    InstanciaEgresos.Egreso()


def ReportarCantidadIngresos():
    InstanciaIngresos.ReportarCantidadIngresos()


def ReportarCantidadEgresos():
    InstanciaEgresos.ReportarCantidadEgresos()


def ReportarTransaccion():
    print("Tus ingresos realizados hasta el momento son:")
    InstanciaIngresos.ReportarCantidadIngresos()
    print("Tus egresos realizados hasta el momento son:")
    InstanciaEgresos.ReportarCantidadEgresos()


def Saldo():
    InstanciaIngresos.SumaIngresos()
    InstanciaIngresos.SumaEgresos()
    TotalCuenta = InstanciaIngresos.SumaIngresos() - InstanciaIngresos.SumaEgresos()
    print(f"Tu saldo total en la cuenta es de $ {TotalCuenta}")


while True:
    print("Menú: ")
    print("(0) Salir")
    print("(1) Inicilizar usuario")
    print("(2) Registrar un ingreso")
    print("(3) Registrar un egreso")
    print("(4) Ver reporte ingresos")
    print("(5) Ver reporte egresos")
    print("(6) Ver reporte de transacciones")
    print("(7) Ver SaldoTotal")
    opcion = int(input("¿Qué opción desea realizar?: "))

    if opcion == 0:
        print("Cerró la consulta")
        break
    elif opcion == 1:
        Usuario()

    elif opcion == 2:
        Ingreso()

    elif opcion == 3:
        Egreso()

    elif opcion == 4:
        print("Ingresos ingresados:")
        ReportarCantidadIngresos()

    elif opcion == 5:
        print("Egresos ingresados:")
        ReportarCantidadEgresos()

    elif opcion == 6:
        ReportarTransaccion()

    elif opcion == 7:
        Saldo()